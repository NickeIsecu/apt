<?php

$METRI_TOKEN = "https://api.telegram.org/bot8059972371:AAGUbp3UBoydWawE8xJ-_4QHzQOuKrITv_g";

$chat_id = "-4694490221";

// $reload = '';

?>

